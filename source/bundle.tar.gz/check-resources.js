#!/usr/bin/env node
// ==========================================
// check-resources.js
// ==========================================
// Chạy script này NGAY TRÊN SERVER PTERODACTYL (cùng chỗ chạy bot) để biết
// server có gánh nổi acorn/acorn-walk (nhẹ) và Playwright+Chromium (nặng)
// hay không, trước khi quyết định cài.
//
// Cách chạy: node check-resources.js

const os = require('os');
const fs = require('fs');
const { execSync } = require('child_process');

function toMB(bytes) {
    return (bytes / 1024 / 1024).toFixed(0);
}

function toGB(bytes) {
    return (bytes / 1024 / 1024 / 1024).toFixed(2);
}

console.log('========================================');
console.log('  KIỂM TRA TÀI NGUYÊN SERVER');
console.log('========================================\n');

// ---- RAM ----
const totalMem = os.totalmem();
const freeMem = os.freemem();
const usedMem = totalMem - freeMem;

console.log('--- RAM ---');
console.log(`Tổng RAM (container thấy được): ${toMB(totalMem)} MB (${toGB(totalMem)} GB)`);
console.log(`Đang dùng: ${toMB(usedMem)} MB`);
console.log(`Còn trống: ${toMB(freeMem)} MB\n`);

// Lưu ý: trên container Docker (Pterodactyl chạy Docker), os.totalmem() đôi
// khi trả về RAM của HOST chứ ko phải giới hạn thật của container (cgroup
// limit). Thử đọc cgroup để chính xác hơn nếu có.
try {
    const cgroupV2 = '/sys/fs/cgroup/memory.max';
    const cgroupV1 = '/sys/fs/cgroup/memory/memory.limit_in_bytes';
    let cgroupLimit = null;

    if (fs.existsSync(cgroupV2)) {
        const val = fs.readFileSync(cgroupV2, 'utf8').trim();
        if (val !== 'max') cgroupLimit = parseInt(val, 10);
    } else if (fs.existsSync(cgroupV1)) {
        const val = fs.readFileSync(cgroupV1, 'utf8').trim();
        const parsed = parseInt(val, 10);
        // Giá trị cực lớn (gần Number.MAX_SAFE_INTEGER) nghĩa là "không giới hạn"
        if (parsed < Number.MAX_SAFE_INTEGER / 2) cgroupLimit = parsed;
    }

    if (cgroupLimit) {
        console.log(`>>> Giới hạn RAM thật của container (cgroup): ${toMB(cgroupLimit)} MB <<<`);
        console.log('(Đây mới là con số quan trọng nếu bạn chạy Pterodactyl/Docker)\n');
    } else {
        console.log('Không đọc được giới hạn cgroup cụ thể - xem RAM limit trực tiếp trong Pterodactyl panel (Server -> Settings) để chắc chắn.\n');
    }
} catch (err) {
    console.log('Không đọc được cgroup (bình thường trên 1 số hệ thống) - xem RAM limit trong Pterodactyl panel.\n');
}

// ---- Disk ----
console.log('--- DISK ---');
try {
    const dfOutput = execSync('df -h . 2>/dev/null || df -h /', { encoding: 'utf8' });
    console.log(dfOutput);
} catch (err) {
    console.log('Không chạy được lệnh df (có thể bị hạn chế trong container). Xem dung lượng disk trong Pterodactyl panel.\n');
}

// ---- CPU ----
console.log('--- CPU ---');
const cpus = os.cpus();
console.log(`Số core CPU thấy được: ${cpus.length}`);
if (cpus.length > 0) {
    console.log(`Model: ${cpus[0].model}\n`);
}

// ---- Đánh giá ----
console.log('========================================');
console.log('  ĐÁNH GIÁ (ước tính, ko phải tuyệt đối)');
console.log('========================================\n');

const freeMB = Math.round(freeMem / 1024 / 1024);

console.log('acorn + acorn-walk (AST parser, dùng để kiểm tra code trước khi');
console.log('chạy sandbox): CỰC NHẸ, ~vài trăm KB, hầu như server nào cũng');
console.log('gánh được, không đáng lo.\n');

console.log('Playwright + Chromium (screenshot web / render HTML->ảnh):');
console.log('- Disk cần thêm: ~300-400 MB (riêng Chromium binary)');
console.log('- RAM cần khi chạy 1 lần: ~150-300 MB tuỳ trang web');
if (freeMB < 512) {
    console.log(`- ⚠️ RAM còn trống hiện tại chỉ ~${freeMB} MB -> RỦI RO CAO, dễ bị`);
    console.log('  OOM-kill (Pterodactyl tự kill process khi vượt giới hạn RAM đã');
    console.log('  set cho server). KHÔNG khuyến nghị cài Playwright lúc này.');
} else if (freeMB < 1024) {
    console.log(`- ⚠️ RAM còn trống ~${freeMB} MB -> CÓ THỂ chạy được nhưng khá sát,`);
    console.log('  nên theo dõi kỹ khi Playwright chạy lần đầu, tránh chạy đồng');
    console.log('  thời nhiều tác vụ nặng cùng lúc với bot.');
} else {
    console.log(`- ✅ RAM còn trống ~${freeMB} MB -> khả năng cao gánh được, nhưng`);
    console.log('  vẫn nên test thử 1 lần cụ thể trước khi coi là chắc chắn.');
}

console.log('\nSau khi chạy xong, gửi lại toàn bộ output này để quyết định bước tiếp theo.');
