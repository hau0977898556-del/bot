// ==========================================
// Sandbox/ast-check.js
// ==========================================
// Phân tích code AI viết ra bằng acorn (parser) + acorn-walk (duyệt cây AST)
// TRƯỚC KHI cho chạy, để:
// 1. Bắt lỗi cú pháp sớm với thông báo rõ ràng (thay vì để process con crash
//    rồi mới biết).
// 2. Trích xuất toàn bộ require('...') mà code gọi tới, đối chiếu với
//    Sandbox/whitelist.js - nếu có bất kỳ module nào CHƯA được duyệt, CHẶN
//    CỨNG không cho chạy (đúng quyết định: "chặn cứng nếu dùng module chưa
//    duyệt", ko chạy 1 phần).
// 3. Phát hiện thêm vài pattern nguy hiểm rõ ràng dù ko qua require() trực
//    tiếp (vd require() động qua biến, eval, Function constructor) - đây là
//    các "cửa hậu" kinh điển để né 1 bộ check chỉ tìm literal string.
//
// LƯU Ý QUAN TRỌNG: file này CẦN 2 package ngoài (acorn, acorn-walk) đã
// được cài qua `npm install acorn acorn-walk` trên server thật. Môi trường
// code lúc viết module này KHÔNG có network để cài/test trực tiếp, nên toàn
// bộ phần dùng acorn được viết theo đúng API chính thức của acorn 8.x +
// acorn-walk 8.x (rất ổn định, ít đổi API qua các bản) - CẦN TỰ TEST LẠI 1
// LẦN trên server thật sau khi cài xong (xem cuối file có sẵn 1 hàm
// selfTest() để chạy tay kiểm tra nhanh).

'use strict';

let acorn, walk;
try {
    acorn = require('acorn');
    walk = require('acorn-walk');
} catch (err) {
    // Không throw ngay ở đây - để index.js tự quyết định báo lỗi thân thiện
    // hơn là để toàn bộ bot crash lúc require file này nếu quên cài package.
    acorn = null;
    walk = null;
}

const whitelist = require('./whitelist.js');

// Các pattern "cửa hậu" kinh điển để né require() literal check: gọi
// require động qua biến, eval, new Function(...), import() động.
// Đây là check bằng regex TRÊN SOURCE THÔ (bên cạnh AST) làm lớp phòng thủ
// kép - vì 1 số cách né (vd `require(['a','x','i','o','s'].join(''))`) khó
// bắt hết bằng walk đơn giản, nhưng chỉ cần cấm hẳn các API nguồn gốc của
// kiểu né tránh này (eval, Function, import động) là chặn được phần lớn.
const FORBIDDEN_PATTERNS = [
    { regex: /\beval\s*\(/, label: 'eval()' },
    { regex: /new\s+Function\s*\(/, label: 'new Function()' },
    { regex: /\bimport\s*\(/, label: 'import() động' },
    { regex: /process\s*\.\s*binding\s*\(/, label: 'process.binding() (API nội bộ Node, có thể bypass permission model)' },
    { regex: /require\s*\.\s*resolve\s*\(/, label: 'require.resolve() (dò đường dẫn module hệ thống)' },
    { regex: /\bglobal(This)?\s*\[\s*['"]process['"]\s*\]/, label: 'truy cập process qua globalThis[...] (kỹ thuật né kiểm tra tĩnh)' },
];

/**
 * Check nhanh bằng regex trên source thô, chạy TRƯỚC acorn (rẻ, bắt sớm các
 * case rõ ràng nhất trước khi tốn công parse AST).
 * @param {string} code
 * @returns {string[]} danh sách vi phạm tìm thấy (rỗng nếu sạch)
 */
function quickPatternCheck(code) {
    const violations = [];
    for (const { regex, label } of FORBIDDEN_PATTERNS) {
        if (regex.test(code)) {
            violations.push(label);
        }
    }
    return violations;
}

/**
 * Parse code bằng acorn, trả về AST hoặc lỗi cú pháp rõ ràng.
 * @param {string} code
 * @returns {{ ok: true, ast: object } | { ok: false, error: string }}
 */
function parseCode(code) {
    if (!acorn) {
        return {
            ok: false,
            error: 'Package "acorn" chưa được cài trên server (chạy: npm install acorn acorn-walk). AST-check bị vô hiệu hoá để tránh chạy code không kiểm tra.'
        };
    }

    try {
        const ast = acorn.parse(code, {
            ecmaVersion: 'latest',
            sourceType: 'script',
            allowReturnOutsideFunction: true // code AI viết có thể chỉ là 1 đoạn script trần
        });
        return { ok: true, ast };
    } catch (err) {
        return { ok: false, error: `Lỗi cú pháp: ${err.message}` };
    }
}

/**
 * Duyệt AST, trích xuất toàn bộ tên module được require() bằng string
 * literal trực tiếp (require('axios'), require("fs")...).
 * KHÔNG bắt được require động qua biến (vd require(x)) - trường hợp đó được
 * coi là VI PHẠM luôn (xem analyzeCode) vì ko thể xác định tĩnh module gì.
 * @param {object} ast
 * @returns {{ literalRequires: string[], dynamicRequireFound: boolean }}
 */
function extractRequires(ast) {
    const literalRequires = new Set();
    let dynamicRequireFound = false;

    walk.simple(ast, {
        CallExpression(node) {
            const isRequireCall =
                node.callee.type === 'Identifier' && node.callee.name === 'require';

            if (!isRequireCall) return;

            const firstArg = node.arguments[0];
            if (firstArg && firstArg.type === 'Literal' && typeof firstArg.value === 'string') {
                literalRequires.add(firstArg.value);
            } else {
                // require(someVariable), require(`template${x}`), require() ko đối số, v.v.
                dynamicRequireFound = true;
            }
        }
    });

    return { literalRequires: Array.from(literalRequires), dynamicRequireFound };
}

/**
 * Hàm chính: phân tích đầy đủ 1 đoạn code, trả về quyết định CÓ CHO CHẠY
 * hay KHÔNG, kèm lý do rõ ràng để hiển thị lại cho user/admin.
 * @param {string} code
 * @returns {{
 *   allowed: boolean,
 *   blockedReasons: string[],
 *   requiredModules: string[],
 *   pendingModules: string[]   // modules đang chờ duyệt, để gợi ý admin approve
 * }}
 */
function analyzeCode(code) {
    const blockedReasons = [];

    // Bước 1: quick pattern check (rẻ, chạy trước)
    const patternViolations = quickPatternCheck(code);
    if (patternViolations.length > 0) {
        blockedReasons.push(`Phát hiện API bị cấm: ${patternViolations.join(', ')}`);
    }

    // Bước 2: parse AST
    const parseResult = parseCode(code);
    if (!parseResult.ok) {
        blockedReasons.push(parseResult.error);
        return { allowed: false, blockedReasons, requiredModules: [], pendingModules: [] };
    }

    // Bước 3: trích xuất require() và check whitelist
    const { literalRequires, dynamicRequireFound } = extractRequires(parseResult.ast);

    if (dynamicRequireFound) {
        blockedReasons.push('Phát hiện require() động (module xác định lúc chạy, ko phải chuỗi cố định) - ko kiểm tra tĩnh được nên bị chặn.');
    }

    const pendingModules = [];
    for (const mod of literalRequires) {
        const check = whitelist.checkModule(mod);
        if (!check.allowed) {
            blockedReasons.push(`"${mod}": ${check.reason}`);
            if (check.category === 'pending' || check.category === 'unknown') {
                pendingModules.push(mod);
            }
        }
    }

    return {
        allowed: blockedReasons.length === 0,
        blockedReasons,
        requiredModules: literalRequires,
        pendingModules
    };
}

/**
 * Hàm tự-kiểm-tra nhanh, chạy tay bằng `node -e "require('./ast-check.js').selfTest()"`
 * sau khi đã `npm install acorn acorn-walk` trên server thật, để xác nhận
 * module hoạt động đúng trước khi tin tưởng đưa vào production.
 */
function selfTest() {
    if (!acorn || !walk) {
        console.log('❌ acorn/acorn-walk chưa được cài. Chạy: npm install acorn acorn-walk');
        return;
    }

    const cases = [
        { code: `console.log(1+1)`, expectAllowed: true, label: 'code thường' },
        { code: `const x = require('path'); console.log(x.join('a','b'))`, expectAllowed: true, label: 'require built-in cho phép (path)' },
        { code: `const fs = require('fs'); fs.readFileSync(__SANDBOX_WORK__ + '/notes.txt','utf8')`, expectAllowed: true, label: 'require fs (được phép ở mức AST, path thật bị Permission Model giới hạn lúc chạy)' },
        { code: `const cp = require('child_process'); cp.execSync('ls')`, expectAllowed: false, label: 'require child_process' },
        { code: `const x = require('some-random-unknown-package-xyz')`, expectAllowed: false, label: 'require module lạ chưa duyệt' },
        { code: `eval('1+1')`, expectAllowed: false, label: 'eval()' },
        { code: `new Function('return 1')()`, expectAllowed: false, label: 'new Function()' },
        { code: `const modName = 'fs'; require(modName)`, expectAllowed: false, label: 'require động qua biến' },
        { code: `function broken( {`, expectAllowed: false, label: 'lỗi cú pháp' },
    ];

    console.log('=== AST-CHECK SELF TEST ===\n');
    let pass = 0;
    for (const c of cases) {
        const result = analyzeCode(c.code);
        const ok = result.allowed === c.expectAllowed;
        if (ok) pass++;
        console.log(`${ok ? '✅' : '❌'} [${c.label}] allowed=${result.allowed} (kỳ vọng ${c.expectAllowed})`);
        if (result.blockedReasons.length > 0) {
            console.log(`   lý do: ${result.blockedReasons.join(' | ')}`);
        }
    }
    console.log(`\n${pass}/${cases.length} test pass.`);
}

module.exports = {
    quickPatternCheck,
    parseCode,
    extractRequires,
    analyzeCode,
    selfTest,
    // Export cờ báo acorn có sẵn hay ko, để index.js check trước khi cho phép
    // tính năng code execution hoạt động (tránh chạy code ko kiểm tra được).
    isAstCheckAvailable: () => acorn !== null && walk !== null
};
