// ==========================================
// Sandbox/executor.js
// ==========================================
// "Cửa ra" chính của toàn bộ hệ sandbox, index.js chỉ cần gọi
// executeInSandbox(userId, code) - mọi bước an toàn (AST-check, whitelist,
// Permission Model scoped path) đều nằm gọn trong này.
//
// Luồng xử lý 1 lần gọi:
// 1. analyzeCode() (Sandbox/ast-check.js) - parse + check require() trước
//    khi chạy. Nếu có module chưa duyệt hoặc pattern nguy hiểm -> TỪ CHỐI
//    CHẠY LUÔN, ko chạy dù chỉ 1 phần (đúng quyết định đã chốt).
// 2. Nếu qua bước 1 -> ensureUserSandbox() (Sandbox/manager.js) đảm bảo có
//    đủ thư mục uploaded/ + work/ cho đúng user đó.
// 3. Spawn 1 process `node` con với Permission Model + giới hạn heap
//    (--max-old-space-size), CHỈ cấp quyền:
//    - đọc: cả uploaded/ (input cố định) và work/ (không gian AI)
//    - ghi: CHỈ work/ (uploaded/ luôn read-only với AI, ko cho sửa/xoá đồ
//      user đã upload)
//    Code AI viết được nối thêm 2 biến __SANDBOX_UPLOADED__/__SANDBOX_WORK__
//    ở đầu (absolute path), để AI biết chỗ đọc/ghi mà ko cần đoán path.
//
// LƯU Ý VỀ RAM: server chạy bot này đo được cgroup memory limit thực tế chỉ
// ~589MB (rất thấp) - mỗi process con chạy code TỰ ĐỘNG bị giới hạn heap qua
// --max-old-space-size (xem MAX_HEAP_MB) để 1 đoạn code lỡ cấp phát dữ liệu
// lớn ko kéo sập toàn bộ container (ảnh hưởng cả bot chính). Nếu server sau
// này nâng cấp RAM, có thể tăng MAX_HEAP_MB/EXECUTION_TIMEOUT_MS ở đây.

'use strict';

const path = require('path');
const { execFile } = require('child_process');
const { ensureUserSandbox } = require('./manager.js');
const { analyzeCode } = require('./ast-check.js');

// Giảm xuống 5s (thay vì 8s bản trước) vì server chạy RAM rất thấp (~589MB
// cgroup limit thực tế đo được) - hạn chế thời gian 1 process con "treo"
// chiếm RAM càng ngắn càng an toàn cho tổng thể bot + các tác vụ khác.
const EXECUTION_TIMEOUT_MS = 5000;
const MAX_OUTPUT_BYTES = 1024 * 100; // ~100KB, giảm nhẹ so với 150KB cũ

// Giới hạn heap V8 cho MỖI process con chạy code - bắt buộc với server RAM
// thấp (~589MB tổng). Không giới hạn thì 1 đoạn code vô tình (hoặc cố ý)
// cấp phát mảng/object lớn có thể ăn hết RAM còn lại của toàn bộ container,
// kéo sập luôn cả bot chính lẫn mọi tiến trình khác đang chạy chung.
// 96MB là mức khá dè dặt, đủ cho code tính toán/xử lý text/file thông
// thường, nhưng chặn sớm trước khi 1 process con ăn quá nhiều.
const MAX_HEAP_MB = 96;

// Tên cờ Permission Model đổi theo version Node (xem index.js bản cũ - giữ
// nguyên logic detect này, chỉ tách ra đây để executor.js tự chứa, ko phải
// import ngược lại từ index.js).
function getPermissionFlag() {
    const [majorStr, minorStr] = process.versions.node.split('.');
    const major = parseInt(majorStr, 10);
    const minor = parseInt(minorStr, 10);

    if (major < 20) return null;
    if (major > 23 || (major === 23 && minor >= 5)) return '--permission';
    return '--experimental-permission';
}

/**
 * Chạy code trong sandbox của đúng 1 user, có AST-check trước.
 * @param {string} userId - Discord user ID, dùng để xác định đúng thư mục sandbox
 * @param {string} code - code Node.js do AI viết ra
 * @returns {Promise<{
 *   ok: boolean,
 *   output: string,
 *   blockedReasons?: string[],
 *   pendingModules?: string[]
 * }>}
 */
function executeInSandbox(userId, code) {
    return new Promise((resolve) => {
        // ---- Bước 1: AST-check trước khi chạy bất cứ thứ gì ----
        const analysis = analyzeCode(code);
        if (!analysis.allowed) {
            return resolve({
                ok: false,
                output: `❌ Code bị từ chối chạy trước khi thực thi:\n- ${analysis.blockedReasons.join('\n- ')}`,
                blockedReasons: analysis.blockedReasons,
                pendingModules: analysis.pendingModules
            });
        }

        // ---- Bước 2: Permission Model có hỗ trợ ko ----
        const permFlag = getPermissionFlag();
        if (!permFlag) {
            return resolve({
                ok: false,
                output: `❌ Node.js hiện tại (${process.version}) quá cũ, ko hỗ trợ Permission Model (cần >= 20.x). Code execution bị vô hiệu hoá để tránh chạy code không sandbox.`
            });
        }

        // ---- Bước 3: đảm bảo sandbox tồn tại, build code với path đã bơm ----
        let sandboxPaths;
        try {
            sandboxPaths = ensureUserSandbox(userId);
        } catch (err) {
            return resolve({ ok: false, output: `❌ Lỗi tạo sandbox: ${err.message}` });
        }

        const { uploaded, work } = sandboxPaths;

        const prelude =
            `const __SANDBOX_UPLOADED__ = ${JSON.stringify(uploaded)};\n` +
            `const __SANDBOX_WORK__ = ${JSON.stringify(work)};\n` +
            `process.chdir(__SANDBOX_WORK__);\n`; // chạy code với cwd = work/, path tương đối tự nhiên rơi vào đúng chỗ

        const fullCode = prelude + code;

        // ---- Bước 4: spawn với Permission Model scoped đúng sandbox ----
        // QUAN TRỌNG: Node KHÔNG (còn) chấp nhận nhiều path dạng
        // "--allow-fs-read=path1,path2" (comma-separated) - phải truyền cờ
        // NHIỀU LẦN, mỗi lần 1 path riêng, nếu không toàn bộ path trong cờ
        // đó bị coi là ko hợp lệ và bị từ chối hết (đã tự kiểm chứng thực tế
        // trước khi chốt cách viết này).
        const args = [
            `--max-old-space-size=${MAX_HEAP_MB}`,
            permFlag,
            `--allow-fs-read=${uploaded}`,
            `--allow-fs-read=${work}`,
            `--allow-fs-write=${work}`, // CHỈ ghi được zone work/ (uploaded/ read-only)
            // Cố tình KO truyền --allow-child-process / --allow-worker /
            // --allow-addons: truyền cờ (kể cả =false) bị Node hiểu là CHO
            // PHÉP, chỉ có KHÔNG truyền mới giữ đúng default-deny.
            '-e',
            fullCode
        ];

        execFile('node', args, {
            timeout: EXECUTION_TIMEOUT_MS,
            maxBuffer: MAX_OUTPUT_BYTES
        }, (error, stdout, stderr) => {
            if (error) {
                if (error.killed) {
                    return resolve({ ok: false, output: `⏱️ Code chạy quá ${EXECUTION_TIMEOUT_MS / 1000}s nên bị dừng (timeout).` });
                }
                // OOM (vượt --max-old-space-size) làm V8 abort process với
                // SIGABRT + in ra 1 đống crash dump kỹ thuật (stack trace GC,
                // địa chỉ bộ nhớ...) - ko có ích gì cho user, thay bằng message
                // dễ hiểu. Nhận diện qua signal (đáng tin hơn so với regex vào
                // nội dung stderr, vì format crash dump có thể đổi giữa các bản V8).
                if (error.signal === 'SIGABRT' || /JavaScript heap out of memory/i.test(stderr || '')) {
                    return resolve({
                        ok: false,
                        output: `💥 Code dùng quá nhiều bộ nhớ (giới hạn ${MAX_HEAP_MB}MB mỗi lần chạy, do server RAM thấp). Thử viết code xử lý theo từng phần nhỏ (stream/chunk) thay vì load hết vào 1 mảng/object lớn cùng lúc.`
                    });
                }
                return resolve({ ok: false, output: (stderr || error.message || 'Unknown error').toString().slice(0, 1500) });
            }
            const out = (stdout || '').toString().trim();
            resolve({
                ok: true,
                output: out ? out.slice(0, 1500) : '(ko có output, dùng console.log để in kết quả)'
            });
        });
    });
}

module.exports = {
    EXECUTION_TIMEOUT_MS,
    MAX_HEAP_MB,
    MAX_OUTPUT_BYTES,
    getPermissionFlag,
    executeInSandbox
};
