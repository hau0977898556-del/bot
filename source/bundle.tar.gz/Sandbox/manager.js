// ==========================================
// Sandbox/manager.js
// ==========================================
// Quản lý sandbox riêng cho mỗi user: ./Sandbox/<safeId>/uploaded/ và
// ./Sandbox/<safeId>/work/
//
// - uploaded/  = nơi lưu file user upload lên qua Discord (AI ĐỌC từ đây,
//   coi như input cố định, AI ko được tự sửa/xoá file trong này)
// - work/      = không gian làm việc của AI, được đọc/ghi/sửa/xoá thoải mái
//   trong phạm vi thư mục này (đây là nơi AI tạo file kết quả, script tạm...)
//
// QUAN TRỌNG VỀ BẢO MẬT: toàn bộ hàm resolve path ở đây PHẢI đảm bảo path
// cuối cùng luôn nằm trong đúng thư mục sandbox của user đó, không cho phép
// thoát ra ngoài bằng "..", symlink lạ, hay ký tự đặc biệt trong tên. Đây là
// lớp phòng thủ chính khi ta CHO PHÉP fs access (khác hẳn với việc chặn
// tuyệt đối như thiết kế cũ) - sai ở đây là lộ toàn bộ file server.

'use strict';

const fs = require('fs');
const path = require('path');

const SANDBOX_ROOT = path.join(__dirname); // = .../Sandbox

/**
 * Biến 1 Discord user ID thành tên thư mục an toàn. Dùng USER ID (số, cố
 * định, ko đổi được) thay vì username hiển thị, vì username có thể đổi bất
 * cứ lúc nào và (ở hệ thống username cũ) có thể chứa ký tự lạ. Vẫn nhận thêm
 * displayName để show cho dễ đọc trong log, nhưng KO dùng nó làm tên thư mục.
 * @param {string} userId - Discord user ID (chuỗi số)
 * @returns {string}
 */
function sanitizeUserId(userId) {
    const cleaned = String(userId || '').replace(/[^0-9]/g, '');
    if (!cleaned) {
        throw new Error('userId không hợp lệ (rỗng sau khi sanitize)');
    }
    return cleaned;
}

/**
 * Trả về object chứa các absolute path cho sandbox của 1 user, và đảm bảo
 * các thư mục đó tồn tại (tạo nếu chưa có).
 * @param {string} userId
 * @returns {{ root: string, uploaded: string, work: string }}
 */
function ensureUserSandbox(userId) {
    const safeId = sanitizeUserId(userId);
    const root = path.join(SANDBOX_ROOT, safeId);
    const uploaded = path.join(root, 'uploaded');
    const work = path.join(root, 'work');

    for (const dir of [root, uploaded, work]) {
        fs.mkdirSync(dir, { recursive: true });
    }

    return { root, uploaded, work };
}

/**
 * Kiểm tra 1 absolute path có thực sự nằm bên trong 1 thư mục gốc cho phép
 * hay không (chống path traversal kiểu "../../"). Dùng path.relative rồi
 * check kết quả không bắt đầu bằng ".." và không phải absolute path khác ổ.
 * @param {string} baseDir - thư mục gốc cho phép (absolute)
 * @param {string} targetPath - path cần kiểm tra (absolute)
 * @returns {boolean}
 */
function isPathInside(baseDir, targetPath) {
    const relative = path.relative(baseDir, targetPath);
    return relative !== '' && !relative.startsWith('..') && !path.isAbsolute(relative);
}

/**
 * Resolve 1 đường dẫn TƯƠNG ĐỐI (do user/AI cung cấp, ví dụ "notes.txt" hay
 * "subdir/file.js") thành absolute path, đảm bảo luôn nằm trong 1 trong 2
 * thư mục sandbox (uploaded hoặc work) của đúng user đó. Nếu path cố tình
 * trỏ ra ngoài (vd "../../../etc/passwd") -> throw lỗi rõ ràng, KHÔNG bao
 * giờ âm thầm "kẹp" nó về trong sandbox (kẹp mù có thể tạo hành vi bất ngờ,
 * thà từ chối thẳng còn hơn).
 * @param {string} userId
 * @param {'uploaded'|'work'} zone
 * @param {string} relativePath
 * @returns {string} absolute path an toàn
 */
function resolveSafePath(userId, zone, relativePath) {
    if (zone !== 'uploaded' && zone !== 'work') {
        throw new Error(`Zone không hợp lệ: ${zone} (chỉ chấp nhận 'uploaded' hoặc 'work')`);
    }

    const { uploaded, work } = ensureUserSandbox(userId);
    const baseDir = zone === 'uploaded' ? uploaded : work;

    // Chuẩn hoá input: loại bỏ null byte (kỹ thuật bypass path check cổ điển)
    const cleanedRelative = String(relativePath || '').replace(/\0/g, '');

    const resolved = path.resolve(baseDir, cleanedRelative);

    if (!isPathInside(baseDir, resolved) && resolved !== baseDir) {
        throw new Error(
            `Path "${relativePath}" nằm ngoài phạm vi sandbox cho phép (${zone}/). ` +
            `Từ chối truy cập để đảm bảo an toàn.`
        );
    }

    return resolved;
}

module.exports = {
    SANDBOX_ROOT,
    sanitizeUserId,
    ensureUserSandbox,
    isPathInside,
    resolveSafePath
};
