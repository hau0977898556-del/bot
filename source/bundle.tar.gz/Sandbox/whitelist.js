// ==========================================
// Sandbox/whitelist.js
// ==========================================
// Quản lý danh sách module AI được phép require() trong code chạy sandbox.
//
// 2 lớp:
// 1. BUILTIN_ALLOWED - built-in module của Node, luôn cho phép, admin liệt
//    kê sẵn (theo đúng yêu cầu: "Zeraa tự liệt kê trước").
// 2. approvedPackages (trong whitelist.json) - npm package ĐÃ được duyệt,
//    admin có thể thêm tay hoặc duyệt qua đề xuất của AI.
//    pendingProposals - npm package AI ĐỀ XUẤT nhưng CHƯA được duyệt. Code
//    dùng module ở trạng thái này vẫn bị CHẶN CỨNG cho tới khi admin gõ
//    "&&approve <module>" trong DM.
//
// State lưu ở ./Sandbox/whitelist.json, sống sót qua restart bot.

'use strict';

const fs = require('fs');
const path = require('path');

const WHITELIST_FILE = path.join(__dirname, 'whitelist.json');

// Built-in module Node cho phép dùng thẳng, ko cần duyệt (an toàn vì đây là
// core Node, ko phải code bên thứ 3 tải qua network).
//
// 'fs' và 'fs/promises' CÓ trong danh sách này (khác thiết kế ban đầu định
// tự viết wrapper "sandboxFs") - đã kiểm chứng thực tế Node Permission Model
// (--allow-fs-read=<path> --allow-fs-write=<path>) chặn ĐÚNG theo path cụ
// thể ở tầng syscall, kể cả path traversal cố ý ("../" thoát ra ngoài path
// được cấp), bất kể code gọi fs kiểu gì. Tin tưởng cơ chế gốc của Node đáng
// tin cậy hơn tự viết 1 lớp wrapper application-level (nhiều bug surface
// hơn). Executor.js sẽ luôn scope --allow-fs-read/write đúng vào sandbox
// của user đó trước khi cho code chạy - AI dùng fs bình thường, ko cần API
// đặc biệt gì, miễn path nằm trong Sandbox/<userId>/.
const BUILTIN_ALLOWED = [
    'fs', 'fs/promises',
    'path', 'crypto', 'util', 'events', 'stream', 'buffer',
    'querystring', 'url', 'string_decoder', 'timers', 'assert',
    'zlib', 'readline'
];

// Built-in nhưng CHỦ ĐỘNG chặn dù có sẵn trong Node - liệt kê rõ để log lỗi
// dễ hiểu hơn thay vì lẫn vào nhóm "chưa được duyệt". Nhóm này KO scope theo
// path được (khác fs), 1 khi cho phép là mở toang sandbox nên giữ chặn cứng.
const BUILTIN_BLOCKED = new Set([
    'child_process', 'cluster',       // spawn process con - phá sandbox hoàn toàn
    'worker_threads',                 // né timeout/permission qua thread khác
    'net', 'dgram', 'tls', 'http', 'http2', 'https', 'dns', // network thô
    'vm', 'inspector', 'v8', 'repl',  // escape sandbox / debug nội bộ
    'os'                              // dò thông tin hệ thống máy chủ
]);

function defaultWhitelistData() {
    return {
        approvedPackages: [],   // ['axios', 'dayjs', ...]
        pendingProposals: []    // [{ module, requestedBy, requestedAt, reason }]
    };
}

function loadWhitelist() {
    try {
        if (fs.existsSync(WHITELIST_FILE)) {
            const data = JSON.parse(fs.readFileSync(WHITELIST_FILE, 'utf8'));
            return {
                approvedPackages: Array.isArray(data.approvedPackages) ? data.approvedPackages : [],
                pendingProposals: Array.isArray(data.pendingProposals) ? data.pendingProposals : []
            };
        }
    } catch (err) {
        console.error("❌ Lỗi đọc Sandbox/whitelist.json:", err);
    }
    return defaultWhitelistData();
}

function saveWhitelist(data) {
    try {
        fs.mkdirSync(path.dirname(WHITELIST_FILE), { recursive: true });
        fs.writeFileSync(WHITELIST_FILE, JSON.stringify(data, null, 2), 'utf8');
    } catch (err) {
        console.error("❌ Lỗi ghi Sandbox/whitelist.json:", err);
    }
}

/**
 * Kiểm tra 1 tên module có được phép require() hay không.
 * @param {string} moduleName
 * @returns {{ allowed: boolean, reason: string, category: 'builtin'|'builtin-blocked'|'approved'|'pending'|'unknown' }}
 */
function checkModule(moduleName) {
    if (BUILTIN_ALLOWED.includes(moduleName)) {
        return { allowed: true, reason: 'Built-in Node module đã được cho phép sẵn.', category: 'builtin' };
    }

    if (BUILTIN_BLOCKED.has(moduleName)) {
        return {
            allowed: false,
            reason: `Module "${moduleName}" là built-in nhưng bị chặn chủ động vì lý do bảo mật (xem BUILTIN_BLOCKED).`,
            category: 'builtin-blocked'
        };
    }

    const data = loadWhitelist();

    if (data.approvedPackages.includes(moduleName)) {
        return { allowed: true, reason: 'Module đã được admin duyệt.', category: 'approved' };
    }

    const pending = data.pendingProposals.find(p => p.module === moduleName);
    if (pending) {
        return {
            allowed: false,
            reason: `Module "${moduleName}" đang chờ admin duyệt (đề xuất lúc ${new Date(pending.requestedAt).toLocaleString('vi-VN')}).`,
            category: 'pending'
        };
    }

    return {
        allowed: false,
        reason: `Module "${moduleName}" chưa từng được biết tới. Cần đề xuất trước (xem proposeModule).`,
        category: 'unknown'
    };
}

/**
 * AI/hệ thống đề xuất 1 module mới cần dùng. Nếu module đã approved hoặc đã
 * pending rồi thì ko thêm trùng.
 * @param {string} moduleName
 * @param {string} requestedBy - Discord user ID hoặc "AI" để rõ nguồn gốc đề xuất
 * @param {string} reason - lý do cần module này (để admin dễ quyết định)
 * @returns {{ added: boolean, message: string }}
 */
function proposeModule(moduleName, requestedBy, reason) {
    if (BUILTIN_ALLOWED.includes(moduleName) || BUILTIN_BLOCKED.has(moduleName)) {
        return { added: false, message: `"${moduleName}" là built-in module, ko cần đề xuất.` };
    }

    const data = loadWhitelist();

    if (data.approvedPackages.includes(moduleName)) {
        return { added: false, message: `"${moduleName}" đã được duyệt từ trước rồi.` };
    }
    if (data.pendingProposals.some(p => p.module === moduleName)) {
        return { added: false, message: `"${moduleName}" đã nằm trong hàng chờ duyệt rồi.` };
    }

    data.pendingProposals.push({
        module: moduleName,
        requestedBy: requestedBy || 'unknown',
        requestedAt: Date.now(),
        reason: reason || '(không có lý do cụ thể)'
    });
    saveWhitelist(data);

    return { added: true, message: `Đã thêm "${moduleName}" vào hàng chờ duyệt.` };
}

/**
 * Admin duyệt 1 module đang pending -> chuyển sang approvedPackages.
 * @param {string} moduleName
 * @returns {{ success: boolean, message: string }}
 */
function approveModule(moduleName) {
    const data = loadWhitelist();

    const pendingIndex = data.pendingProposals.findIndex(p => p.module === moduleName);
    if (pendingIndex === -1) {
        // Cho phép admin duyệt thẳng dù chưa có ai đề xuất (admin tự thêm tay)
        if (data.approvedPackages.includes(moduleName)) {
            return { success: false, message: `"${moduleName}" đã được duyệt từ trước rồi.` };
        }
        data.approvedPackages.push(moduleName);
        saveWhitelist(data);
        return { success: true, message: `Đã thêm "${moduleName}" vào whitelist (duyệt trực tiếp, ko qua đề xuất).` };
    }

    data.pendingProposals.splice(pendingIndex, 1);
    if (!data.approvedPackages.includes(moduleName)) {
        data.approvedPackages.push(moduleName);
    }
    saveWhitelist(data);

    return { success: true, message: `Đã duyệt "${moduleName}". AI có thể dùng module này từ giờ.` };
}

/**
 * Admin từ chối 1 module đang pending -> xoá khỏi hàng chờ (KHÔNG thêm vào
 * blacklist riêng, chỉ đơn giản là ko có trong approved -> vẫn bị chặn nếu
 * AI đề xuất lại thì phải đề xuất lại từ đầu).
 * @param {string} moduleName
 * @returns {{ success: boolean, message: string }}
 */
function denyModule(moduleName) {
    const data = loadWhitelist();
    const pendingIndex = data.pendingProposals.findIndex(p => p.module === moduleName);

    if (pendingIndex === -1) {
        return { success: false, message: `"${moduleName}" không có trong hàng chờ duyệt.` };
    }

    data.pendingProposals.splice(pendingIndex, 1);
    saveWhitelist(data);

    return { success: true, message: `Đã từ chối "${moduleName}".` };
}

module.exports = {
    WHITELIST_FILE,
    BUILTIN_ALLOWED,
    BUILTIN_BLOCKED,
    loadWhitelist,
    saveWhitelist,
    checkModule,
    proposeModule,
    approveModule,
    denyModule
};
