// ==========================================
// Checksuspicious/filter.js
// ==========================================
// Module tính "điểm nghi vấn" cho member trong server. CHỈ tính điểm + lưu
// state, KHÔNG tự ban/kick/mute ai — việc DM cảnh báo cho admin do index.js
// gọi khi tổng điểm 1 user vượt ngưỡng, để admin tự xem xét bằng tay.
//
// Mỗi rule chỉ được cộng điểm ĐÚNG 1 LẦN cho mỗi user (tránh vòng lặp/spam
// DM liên tục nếu rule cứ tái trigger).
//
// State lưu ở ./log.json (cùng thư mục), sống sót qua restart bot.

const fs = require('fs');
const path = require('path');

const LOG_FILE = path.join(__dirname, 'log.json');

// ---- Cấu hình ngưỡng (chỉnh trực tiếp ở đây nếu cần đổi độ nhạy) ----
const QUESTION_WINDOW_MS = 5 * 60 * 1000; // 5 phút đầu sau khi join
const QUESTION_THRESHOLD = 3;             // >=3 câu hỏi trong khoảng đó
const NO_CHAT_DAYS = 3;                   // 3 ngày liền ko chat tin nào
const OLD_ACCOUNT_YEAR = 2023;            // acc tạo từ năm này trở về trước
const BADGE_THRESHOLD = 3;                // cần >= 3 badge Discord để coi là "có dấu hiệu uy tín"
const FLAG_SCORE_THRESHOLD = 2;           // tổng điểm >= 2 thì DM cho admin
const MEMBER_ROLE_NAME = 'Member';        // tên role check (theo tên, ko cần ID)

// ---- Đọc / ghi log.json ----
function loadLog() {
    try {
        if (fs.existsSync(LOG_FILE)) {
            return JSON.parse(fs.readFileSync(LOG_FILE, 'utf8'));
        }
    } catch (err) {
        console.error("❌ Lỗi đọc Checksuspicious/log.json:", err);
    }
    return { users: {} };
}

function saveLog(data) {
    try {
        fs.mkdirSync(path.dirname(LOG_FILE), { recursive: true });
        fs.writeFileSync(LOG_FILE, JSON.stringify(data, null, 2), 'utf8');
    } catch (err) {
        console.error("❌ Lỗi ghi Checksuspicious/log.json:", err);
    }
}

function getOrCreateEntry(data, userId, guildId, joinedAt) {
    if (!data.users[userId]) {
        data.users[userId] = {
            guildId: guildId || null,
            joinedAt: joinedAt || Date.now(),
            lastMessageAt: joinedAt || Date.now(),
            questionCount: 0,
            score: 0,
            rulesTriggered: [], // vd: ['question_spam', 'no_chat_3d']
            reasons: [],        // text giải thích tương ứng, để show cho admin
            flagged: false      // đã DM admin lần nào chưa (ko DM lặp lại)
        };
    }
    return data.users[userId];
}

// Heuristic nhận diện câu hỏi tiếng Việt (rule-based, ko dùng AI cho việc này)
function isQuestionLike(content) {
    const c = content.trim().toLowerCase();
    if (c.length < 2) return false;
    if (c.endsWith('?')) return true;
    const questionWords = [
        'ko biết', 'không biết', 'là gì', 'là ai', 'ở đâu', 'khi nào', 'bao giờ',
        'sao lại', 'tại sao', 'vì sao', 'làm sao', 'làm thế nào', 'thế nào',
        'ai là', 'cái gì', 'j v', 'gì v', 'gì vậy', 'sao v', 'sao vậy',
        'có ai', 'ad ơi', 'admin ơi', 'mod ơi', 'cho hỏi', 'hỏi tí', 'hỏi chút'
    ];
    return questionWords.some(w => c.includes(w));
}

// Cộng điểm 1 lần duy nhất cho mỗi rule (tránh cộng dồn lặp lại cùng 1 rule)
function addScore(entry, ruleKey, reasonText) {
    if (entry.rulesTriggered.includes(ruleKey)) return false;
    entry.rulesTriggered.push(ruleKey);
    entry.score += 1;
    entry.reasons.push(reasonText);
    return true;
}

// ---- RULE A: hỏi han dồn dập ngay lúc mới join ----
// Gọi mỗi khi user (đang được track) gửi 1 tin nhắn.
function checkQuestionSpam(entry, messageContent) {
    if (entry.rulesTriggered.includes('question_spam')) return false;
    if (Date.now() - entry.joinedAt > QUESTION_WINDOW_MS) return false;

    if (isQuestionLike(messageContent)) {
        entry.questionCount += 1;
    }
    if (entry.questionCount >= QUESTION_THRESHOLD) {
        return addScore(entry, 'question_spam', `Hỏi ${entry.questionCount} câu trong ${QUESTION_WINDOW_MS / 60000} phút đầu sau khi join`);
    }
    return false;
}

// ---- RULE B: vừa được thêm role "Member" mà đang ko online ----
// Gọi khi phát hiện role Member vừa được add (GuildMemberUpdate), kèm status hiện tại.
function checkMemberRoleOffline(entry, presenceStatus) {
    if (entry.rulesTriggered.includes('member_role_offline')) return false;
    if (!presenceStatus) return false; // ko lấy được presence -> bỏ qua, tránh flag oan vì thiếu data
    if (presenceStatus === 'online') return false;
    return addScore(entry, 'member_role_offline', `Vừa được thêm role "${MEMBER_ROLE_NAME}" nhưng status ko online (status hiện tại: ${presenceStatus})`);
}

// ---- RULE C: 3 ngày liền ko chat tin nào ----
// Gọi định kỳ (setInterval) cho từng user đang track.
function checkNoChatStreak(entry) {
    if (entry.rulesTriggered.includes('no_chat_3d')) return false;
    const daysSinceLastMsg = (Date.now() - entry.lastMessageAt) / (24 * 60 * 60 * 1000);
    if (daysSinceLastMsg < NO_CHAT_DAYS) return false;
    return addScore(entry, 'no_chat_3d', `Ko chat tin nào suốt ${daysSinceLastMsg.toFixed(1)} ngày (>= ${NO_CHAT_DAYS} ngày) kể từ lần chat cuối/lúc join`);
}

// ---- RULE D: acc lâu năm (<= OLD_ACCOUNT_YEAR) mà chưa từng có dấu hiệu nitro/đủ badge ----
// Gọi 1 lần khi có dịp nhìn thấy đối tượng discordUser đầy đủ (vd lúc add role Member).
// LƯU Ý: Discord API ko cho bot biết trực tiếp "user có đang sub Nitro hay ko" (dữ liệu riêng
// tư). Đây chỉ là heuristic gián tiếp qua avatar/banner động (chỉ Nitro mới có được).
function checkOldAccountNoBadges(entry, discordUser) {
    if (entry.rulesTriggered.includes('old_account_no_badges')) return false;

    const createdYear = new Date(discordUser.createdTimestamp).getFullYear();
    if (createdYear > OLD_ACCOUNT_YEAR) return false;

    const badges = discordUser.flags?.toArray() ?? [];
    const hasAnimatedAvatar = discordUser.avatar?.startsWith('a_') ?? false;
    const hasAnimatedBanner = discordUser.banner?.startsWith('a_') ?? false;
    const nitroHint = hasAnimatedAvatar || hasAnimatedBanner;

    if (nitroHint) return false;
    if (badges.length >= BADGE_THRESHOLD) return false;

    return addScore(entry, 'old_account_no_badges', `Acc tạo năm ${createdYear} (<= ${OLD_ACCOUNT_YEAR}) nhưng ko có dấu hiệu Nitro và chỉ có ${badges.length} badge (< ${BADGE_THRESHOLD})`);
}

module.exports = {
    LOG_FILE,
    QUESTION_WINDOW_MS,
    QUESTION_THRESHOLD,
    NO_CHAT_DAYS,
    OLD_ACCOUNT_YEAR,
    BADGE_THRESHOLD,
    FLAG_SCORE_THRESHOLD,
    MEMBER_ROLE_NAME,
    loadLog,
    saveLog,
    getOrCreateEntry,
    isQuestionLike,
    checkQuestionSpam,
    checkMemberRoleOffline,
    checkNoChatStreak,
    checkOldAccountNoBadges
};
