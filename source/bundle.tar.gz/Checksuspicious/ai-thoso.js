// ==========================================
// Checksuspicious/ai-thoso.js
// ==========================================
// "AI thô sơ" - bộ phân tích văn bản tiếng Việt tự thân, KHÔNG gọi API AI
// ngoài (Groq/DeepSeek). Toàn bộ là rule-based + thống kê tần suất từ, viết
// tay để: (1) nắm ý định câu hỏi tốt hơn match từ khoá cứng, (2) chấm điểm
// "độ nhạy cảm/dò hỏi" của nội dung tin nhắn. Kết quả gộp thành 1 điểm số
// duy nhất, dùng làm 1 rule bổ sung cho Checksuspicious/filter.js.
//
// Lý do tự viết thay vì gọi Groq: tiết kiệm token (module này chạy trên MỌI
// tin nhắn của member mới, gọi AI ngoài cho từng tin sẽ rất tốn), và tránh
// bị model general-purpose "đoán bừa" khi chưa được train riêng cho domain
// tiếng Việt teen-code + ngữ cảnh soi gián điệp.
//
// Toàn bộ file chỉ export qua module.exports ở cuối, không có side-effect
// khi require (không tự đọc/ghi file gì ở đây, phần log vẫn nằm ở filter.js).

'use strict';

// ==========================================
// PHẦN 1: TỪ ĐIỂN CHUẨN HOÁ TEEN-CODE / VIẾT TẮT
// ==========================================
// Bảng ánh xạ viết tắt -> dạng đầy đủ, để các bước phân tích phía sau (đếm
// từ khoá, phân loại intent) không bị trượt vì người dùng gõ tắt.
// Càng nhiều entry càng đỡ bỏ sót, nhưng phải cẩn thận tránh đè lên từ thật
// (vd "m" viết tắt "mày" nhưng cũng là đơn vị đo, nên chỉ áp dụng khi đứng
// riêng 1 token, không áp dụng giữa chuỗi số như "100m").
const TEENCODE_MAP = {
    // Đại từ nhân xưng
    'm': 'mày', 't': 'tao', 'tui': 'tôi', 'tao': 'tao', 'mk': 'mình',
    'ng': 'người', 'nguoi': 'người',

    // Phủ định / trạng từ phổ biến
    'ko': 'không', 'k': 'không', 'hok': 'không', 'khong': 'không',
    'kg': 'không', 'hông': 'không', 'hem': 'không',
    'bit': 'biết', 'bt': 'biết', 'biet': 'biết',
    'bth': 'bình thường', 'binh thuong': 'bình thường',
    'dc': 'được', 'đc': 'được', 'duoc': 'được',
    'ms': 'mới', 'moi': 'mới',
    'r': 'rồi', 'roi': 'rồi',
    'vs': 'với', 'voi': 'với',
    'z': 'vậy', 'zậy': 'vậy', 'v': 'vậy', 'vay': 'vậy',
    'j': 'gì', 'gi': 'gì',
    'wa': 'quá',
    'ok': 'đồng ý', 'oke': 'đồng ý', 'okie': 'đồng ý',
    'thik': 'thích', 'thich': 'thích',
    'lm': 'làm', 'lam': 'làm',
    'nch': 'nói chuyện', 'ncc': 'nói chuyện',
    'ib': 'nhắn tin riêng', 'inbox': 'nhắn tin riêng',
    'dm': 'nhắn tin riêng', // trong ngữ cảnh discord "dm" = direct message
    'add': 'kết bạn', 'kb': 'kết bạn',
    'sv': 'server', 'ser': 'server',
    'ad': 'admin', 'adm': 'admin',
    'mod': 'điều hành viên',
    'acc': 'tài khoản', 'account': 'tài khoản',
    'nick': 'tài khoản',
    'pass': 'mật khẩu', 'mk2': 'mật khẩu', // "mk" đã map ở trên là "mình", cẩn thận ngữ cảnh
    'link': 'đường dẫn',
    'tks': 'cảm ơn', 'thanks': 'cảm ơn', 'thank': 'cảm ơn', 'cam on': 'cảm ơn',
    'sr': 'xin lỗi', 'sorry': 'xin lỗi',
    'plz': 'làm ơn', 'please': 'làm ơn', 'pls': 'làm ơn',
    'ny': 'người yêu',
    'nt': 'nhắn tin',
    'kb2': 'kết bạn',
    'dt': 'điện thoại', 'sdt': 'số điện thoại',
    'đt': 'điện thoại',
    'ny2': 'người yêu',
};

// Regex cắt token: giữ chữ cái tiếng Việt có dấu, số, và dấu câu quan trọng (?)
const TOKEN_REGEX = /[a-zà-ỹ0-9]+|\?|!/gi;

/**
 * Tokenize 1 câu thành mảng token thường (lowercase), loại bỏ khoảng trắng thừa.
 * @param {string} text
 * @returns {string[]}
 */
function tokenize(text) {
    if (!text || typeof text !== 'string') return [];
    const lower = text.toLowerCase().trim();
    const matches = lower.match(TOKEN_REGEX);
    return matches ? matches : [];
}

/**
 * Chuẩn hoá 1 câu: tách token, thay teen-code bằng dạng đầy đủ (nếu match),
 * rồi ghép lại thành câu. Dùng cho các bước phân tích phía sau để tăng độ
 * chính xác khi so khớp từ khoá/cụm từ.
 * @param {string} text
 * @returns {{ tokens: string[], normalizedTokens: string[], normalizedText: string }}
 */
function normalizeTeencode(text) {
    const tokens = tokenize(text);
    const normalizedTokens = tokens.map(tok => {
        // Không áp dụng map cho token là thuần số (tránh phá số liệu, id, v.v.)
        if (/^\d+$/.test(tok)) return tok;
        return TEENCODE_MAP[tok] || tok;
    });
    return {
        tokens,
        normalizedTokens,
        normalizedText: normalizedTokens.join(' ')
    };
}

/**
 * Đếm số ký tự lặp liên tiếp bất thường (vd "saooooo", "dạắắắ") - dấu hiệu
 * nhắn tin gấp gáp/cảm xúc mạnh, dùng làm 1 tín hiệu phụ cho phân tích giọng
 * điệu ở Phần 3.
 * @param {string} text
 * @returns {number} số cụm ký tự lặp >=3 lần tìm thấy
 */
function countElongatedChars(text) {
    if (!text) return 0;
    const matches = text.match(/(.)\1{2,}/g);
    return matches ? matches.length : 0;
}

// ==========================================
// PHẦN 2: INTENT CLASSIFIER - PHÂN LOẠI CÂU HỎI CÓ TRỌNG SỐ
// ==========================================
// Thay cho match từ khoá cứng kiểu isQuestionLike() cũ (chỉ true/false),
// classifier này CHO ĐIỂM theo nhiều tín hiệu cộng dồn rồi mới quyết định,
// nên đỡ trượt các câu hỏi gián tiếp ("t mới vô, đây là gì thế" - kiểu câu
// này isQuestionLike cũ bị FAIL) và đỡ bắt nhầm câu cảm thán có dấu "?" giả
// (vd "ơ??" chỉ là ngạc nhiên, ko hẳn là hỏi cần thông tin).
//
// Nguyên lý: cộng điểm theo 4 nhóm tín hiệu độc lập, threshold hoá ở cuối.
// Đây KHÔNG phải machine learning thật (không train từ dữ liệu), mà là
// "expert system" thủ công - vẫn được gọi là 1 dạng AI thô sơ hợp lệ (rule-
// based reasoning system), phù hợp quy mô 1 bot Discord chứ ko cần cả pipeline
// train model riêng.

// Nhóm A: từ để hỏi (wh-words) tiếng Việt - tín hiệu MẠNH nhất
const WH_WORDS = [
    'gì', 'ai', 'đâu', 'nào', 'sao', 'thế nào', 'ra sao', 'khi nào',
    'bao giờ', 'bao lâu', 'bao nhiêu', 'mấy', 'vì sao', 'tại sao',
    'làm sao', 'làm thế nào', 'kiểu gì'
];

// Nhóm B: cụm mở đầu xin/nhờ thông tin - tín hiệu TRUNG BÌNH
const REQUEST_PHRASES = [
    'cho hỏi', 'hỏi tí', 'hỏi chút', 'hỏi xíu', 'muốn hỏi', 'ai biết',
    'có ai biết', 'chỉ giúp', 'chỉ mình', 'chỉ tôi', 'chỉ em',
    'ai chỉ', 'giúp mình', 'giúp em', 'giúp t', 'giúp tôi',
    'admin ơi', 'ad ơi', 'mod ơi', 'mọi người ơi'
];

// Nhóm C: dấu câu / hình thái câu hỏi - tín hiệu YẾU (dễ bị giả, vd cảm thán)
const QUESTION_PUNCT_PATTERNS = [
    /\?\s*$/,           // kết thúc bằng dấu hỏi
    /^(ơ|ủa|hả|hử)\b/,  // mở đầu bằng thán từ nghi vấn
];

// Nhóm D: "tiểu từ nghi vấn" cuối câu - tín hiệu TRUNG BÌNH, đặc trưng
// tiếng Việt (câu hỏi Yes/No kiểu "...không?", "...à?", "...hả?", "...chưa?")
const QUESTION_PARTICLES = ['không', 'ko', 'à', 'hả', 'chưa', 'nhỉ', 'phỏng', 'ư'];

const INTENT_SCORE_THRESHOLD = 1.5; // >= điểm này thì coi là câu hỏi thật sự

/**
 * Phân tích 1 câu, trả về điểm "độ chắc chắn là câu hỏi" + breakdown lý do.
 * Điểm càng cao càng chắc là câu hỏi cần thông tin (không phải cảm thán suông).
 * @param {string} rawText
 * @returns {{ score: number, isQuestion: boolean, signals: string[] }}
 */
function classifyQuestionIntent(rawText) {
    if (!rawText || typeof rawText !== 'string') {
        return { score: 0, isQuestion: false, signals: [] };
    }

    const { normalizedText, normalizedTokens } = normalizeTeencode(rawText);
    let score = 0;
    const signals = [];

    // Nhóm A: wh-words (mỗi từ tìm thấy +1.5, cộng dồn nhưng cap 3 để tránh
    // 1 câu dài liệt kê nhiều wh-word ảo làm lệch điểm)
    let whHits = 0;
    for (const w of WH_WORDS) {
        if (normalizedText.includes(w)) whHits++;
    }
    if (whHits > 0) {
        const whScore = Math.min(whHits, 2) * 1.5;
        score += whScore;
        signals.push(`wh-word x${whHits} (+${whScore})`);
    }

    // Nhóm B: cụm xin/nhờ thông tin (+1.2 mỗi cụm, cap 2 cụm)
    let reqHits = 0;
    for (const p of REQUEST_PHRASES) {
        if (normalizedText.includes(p)) reqHits++;
    }
    if (reqHits > 0) {
        const reqScore = Math.min(reqHits, 2) * 1.2;
        score += reqScore;
        signals.push(`request-phrase x${reqHits} (+${reqScore})`);
    }

    // Nhóm C: dấu câu nghi vấn (+0.7, tín hiệu yếu vì dễ giả)
    const punctHit = QUESTION_PUNCT_PATTERNS.some(re => re.test(rawText.trim().toLowerCase()));
    if (punctHit) {
        score += 0.7;
        signals.push('question-punctuation (+0.7)');
    }

    // Nhóm D: tiểu từ nghi vấn cuối câu (+1.6 - khá đặc trưng cho câu hỏi
    // Yes/No kiểu tiếng Việt, vd "...chưa?", "...nhỉ", nên trọng số gần
    // ngang wh-word dù đứng 1 mình)
    const lastToken = normalizedTokens[normalizedTokens.length - 1];
    const secondLastToken = normalizedTokens[normalizedTokens.length - 2];
    const particleAtEnd = QUESTION_PARTICLES.includes(lastToken) || QUESTION_PARTICLES.includes(secondLastToken);
    if (particleAtEnd) {
        score += 1.6;
        signals.push('question-particle-cuối-câu (+1.6)');
    }

    // Điều chỉnh: câu quá ngắn (1 từ) dù match wh-word cũng khó chắc là hỏi
    // thật (vd chỉ gõ "gì" một mình thường là cảm thán/troll, ko phải hỏi)
    if (normalizedTokens.length <= 1) {
        score = Math.max(0, score - 1.0);
        signals.push('câu quá ngắn, giảm độ tin cậy (-1.0)');
    }

    return {
        score: Math.round(score * 10) / 10,
        isQuestion: score >= INTENT_SCORE_THRESHOLD,
        signals
    };
}

// ==========================================
// PHẦN 3: PHÁT HIỆN NỘI DUNG "DÒ HỎI NỘI BỘ / NHẠY CẢM"
// ==========================================
// Đây là phần khác biệt với Phần 2: Phần 2 chỉ hỏi "đây có phải câu hỏi
// không", Phần 3 hỏi "nếu là câu hỏi, nó đang HỎI VỀ CÁI GÌ" - cụ thể là có
// đang nhắm vào thông tin nội bộ/nhạy cảm của server hay không (ai là
// admin/mod, quy trình bảo mật, thông tin cá nhân người khác, lịch làm việc
// nội bộ, cấu trúc quyền hạn...). Đây mới là tín hiệu THỰC SỰ liên quan tới
// nghi vấn "dò la", khác với chỉ hỏi han thông thường ("kênh nào để chat").
//
// Thiết kế thành các NHÓM chủ đề, mỗi nhóm có trọng số nghi vấn riêng (nhóm
// càng "nhạy" - hỏi về quyền hạn, bảo mật - trọng số càng cao so với nhóm
// chỉ mang tính tò mò thông thường).

const SENSITIVE_TOPIC_GROUPS = [
    {
        key: 'admin_identity',
        weight: 1.8,
        label: 'Dò hỏi danh tính/quyền hạn admin-mod',
        phrases: [
            'ai là admin', 'ai là chủ server', 'ai là owner', 'chủ sv là ai',
            'admin là ai', 'mod là ai', 'ai quản lý server', 'ai đứng đầu',
            'admin tên gì', 'owner tên gì', 'liên hệ admin', 'sđt admin',
            'số điện thoại admin', 'facebook admin', 'admin ở đâu',
            'admin làm nghề gì', 'admin bao nhiêu tuổi', 'lịch admin online',
            'khi nào admin online', 'admin hay online lúc nào'
        ]
    },
    {
        key: 'security_process',
        weight: 2.0,
        label: 'Dò hỏi quy trình bảo mật/kiểm duyệt',
        phrases: [
            'làm sao để tránh bị ban', 'sao để né mod', 'bot check những gì',
            'cách qua mặt', 'né được kiểm duyệt', 'auto mod hoạt động sao',
            'bot có log tin nhắn ko', 'server có theo dõi ko', 'ai xem được tin nhắn',
            'tin nhắn có bị lưu ko', 'log lại ko', 'có ai đọc dm ko',
            'làm sao vào kênh riêng', 'quyền admin cấp sao', 'cách lên mod',
            'cách trở thành mod', 'tuyển mod ko', 'ứng tuyển admin'
        ]
    },
    {
        key: 'personal_info_others',
        weight: 1.6,
        label: 'Dò hỏi thông tin cá nhân người khác',
        phrases: [
            'nhà bạn ở đâu', 'học trường nào', 'làm ở đâu', 'số điện thoại của',
            'facebook của', 'zalo của', 'địa chỉ nhà', 'tên thật là gì',
            'quê ở đâu', 'đang ở đâu vậy', 'sống ở đâu'
        ]
    },
    {
        key: 'internal_schedule',
        weight: 1.3,
        label: 'Dò hỏi lịch trình/hoạt động nội bộ',
        phrases: [
            'khi nào họp', 'lịch làm việc', 'giờ nào đông người',
            'khi nào ít mod', 'lúc nào vắng admin', 'giờ nào ko ai trực',
            'ai trực hôm nay', 'ai online hôm nay'
        ]
    }
];

// QUAN TRỌNG: các phrase ở trên được viết tay bằng tiếng Việt tự nhiên, nhưng
// detectSensitiveTopics() so khớp trên normalizedText (đã chạy qua
// normalizeTeencode, ví dụ "mod" -> "điều hành viên", "dm" -> "nhắn tin
// riêng"). Nếu so khớp trực tiếp phrase gốc, các cụm chứa từ bị teen-code
// map sẽ KHÔNG BAO GIỜ match được (vd "mod là ai" sẽ ko match vì text thật
// đã thành "điều hành viên là ai"). Vì vậy chuẩn hoá luôn phrase list qua
// cùng 1 hàm normalizeTeencode ngay khi module load, đảm bảo 2 bên luôn
// cùng 1 "bảng chữ cái" khi so khớp - tránh phải nhớ viết tay 2 bản.
for (const group of SENSITIVE_TOPIC_GROUPS) {
    group.phrases = group.phrases.map(p => normalizeTeencode(p).normalizedText);
}

/**
 * Phân tích nội dung xem có chạm tới các nhóm chủ đề nhạy cảm/nội bộ hay
 * không. Match theo cụm từ trên normalizedText (sau teen-code normalize).
 * @param {string} rawText
 * @returns {{ score: number, matchedGroups: {key:string,label:string,weight:number,matchedPhrase:string}[] }}
 */
function detectSensitiveTopics(rawText) {
    if (!rawText || typeof rawText !== 'string') {
        return { score: 0, matchedGroups: [] };
    }

    const { normalizedText } = normalizeTeencode(rawText);
    let score = 0;
    const matchedGroups = [];

    for (const group of SENSITIVE_TOPIC_GROUPS) {
        for (const phrase of group.phrases) {
            if (normalizedText.includes(phrase)) {
                score += group.weight;
                matchedGroups.push({
                    key: group.key,
                    label: group.label,
                    weight: group.weight,
                    matchedPhrase: phrase
                });
                break; // 1 nhóm chỉ tính 1 lần dù match nhiều cụm trong cùng câu
            }
        }
    }

    return { score: Math.round(score * 10) / 10, matchedGroups };
}

// ==========================================
// PHẦN 4: TỔNG HỢP - GỘP TẤT CẢ TÍN HIỆU THÀNH 1 ĐIỂM SỐ DUY NHẤT
// ==========================================
// Đây là "cửa ra" chính của module, được Checksuspicious/filter.js gọi.
// Gộp: (a) độ chắc chắn là câu hỏi (Phần 2), (b) độ nhạy cảm chủ đề (Phần 3),
// và (c) 1 tín hiệu phụ về giọng điệu gấp gáp (elongated chars - Phần 1) để
// tinh chỉnh nhẹ, KHÔNG dùng làm tín hiệu chính vì bản thân nó ko đặc trưng
// cho "dò la" (ai cũng có thể gõ "reeeeee" khi vui/bực chứ ko liên quan).
//
// Điểm cuối cùng (analyzedMessageScore) là con số liên tục, filter.js sẽ tự
// quyết định ngưỡng nào thì cộng vào rule tổng của Checksuspicious - module
// này chỉ có trách nhiệm PHÂN TÍCH, không tự quyết định "ai bị flag".

/**
 * Phân tích đầy đủ 1 tin nhắn, trả về toàn bộ breakdown để filter.js hoặc
 * admin (khi debug) có thể đọc hiểu lý do.
 * @param {string} rawText
 * @returns {{
 *   isQuestion: boolean,
 *   questionScore: number,
 *   sensitiveScore: number,
 *   sensitiveGroups: string[],
 *   combinedScore: number,
 *   signals: string[]
 * }}
 */
function analyzeMessage(rawText) {
    const questionResult = classifyQuestionIntent(rawText);
    const sensitiveResult = detectSensitiveTopics(rawText);
    const elongatedCount = countElongatedChars(rawText);

    // Trọng số tổng hợp: sensitive topic quan trọng hơn nhiều so với việc chỉ
    // đơn thuần là 1 câu hỏi thông thường (hỏi kênh chat ở đâu KHÔNG đáng
    // ngờ bằng hỏi "ai là admin, lịch trực thế nào").
    let combinedScore = 0;
    const signals = [...questionResult.signals];

    if (questionResult.isQuestion) {
        combinedScore += 1.0; // câu hỏi thông thường: đóng góp cố định, ko cộng dồn theo questionScore để tránh lệch quá nhiều bởi câu dài
    }

    if (sensitiveResult.score > 0) {
        combinedScore += sensitiveResult.score; // chủ đề nhạy cảm: cộng nguyên điểm, đây là tín hiệu MẠNH
        for (const g of sensitiveResult.matchedGroups) {
            signals.push(`sensitive-topic:${g.key} (+${g.weight}) - matched "${g.matchedPhrase}"`);
        }
    }

    // Tín hiệu phụ: nhắn dồn dập/gấp gáp bất thường (elongated chars nhiều)
    // chỉ cộng nhẹ, và CHỈ khi đã có ít nhất 1 tín hiệu chính khác (tránh
    // 1 tin nhắn vui vẻ bình thường kiểu "hayyyy quaaaa" tự nhiên bị tính điểm)
    if (elongatedCount >= 2 && (questionResult.isQuestion || sensitiveResult.score > 0)) {
        combinedScore += 0.3;
        signals.push(`giọng điệu gấp gáp (elongated chars x${elongatedCount}) (+0.3)`);
    }

    return {
        isQuestion: questionResult.isQuestion,
        questionScore: questionResult.score,
        sensitiveScore: sensitiveResult.score,
        sensitiveGroups: sensitiveResult.matchedGroups.map(g => g.key),
        combinedScore: Math.round(combinedScore * 10) / 10,
        signals
    };
}

module.exports = {
    TEENCODE_MAP,
    tokenize,
    normalizeTeencode,
    countElongatedChars,
    WH_WORDS,
    REQUEST_PHRASES,
    QUESTION_PARTICLES,
    INTENT_SCORE_THRESHOLD,
    classifyQuestionIntent,
    SENSITIVE_TOPIC_GROUPS,
    detectSensitiveTopics,
    analyzeMessage
};
